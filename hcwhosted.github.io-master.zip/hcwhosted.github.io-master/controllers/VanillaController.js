import BaseController from './BaseController.js';

class VanillaController extends BaseController {}

window.controller = new VanillaController();
